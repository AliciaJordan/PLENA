import SwiftUI
@main
struct PLENA_App: App {
    var body: some Scene {
        WindowGroup {
            LoginView() // Punto de entrada
        }
    }
}

