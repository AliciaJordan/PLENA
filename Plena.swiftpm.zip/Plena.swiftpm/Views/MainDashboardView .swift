import SwiftUI
struct MainDashboardView: View {
    @State private var activeTab: MainDashboardView.TabToShow?
    @Environment(\.dismiss) var dismiss // Para cerrar sesión
    
    enum TabToShow {
        case checkIn
        case health
    }
    let features: [(icon: String, title: String, subtitle: String, color: Color, tab: TabToShow?)] = [
        ("calendar", "Daily Check-In", "Registra tu progreso", .pastelGreen, .checkIn),
        ("heart.fill", "Health", "Monitor vital", .pastelPink, .health),
        ("face.smiling", "Emotions", "Estado emocional", .pastelPurple, nil)
    ]
    var body: some View {
        NavigationStack {
            Group {
                if let tab = activeTab {
                    switch tab {
                    case .checkIn:
                        CheckInTabView()
                    case .health:
                        HealthTabView()
                    }
                } else {
                    HStack {
                        Button {
                            dismiss() // Regresa a LoginView
                        } label: {
                            Image(systemName: "chevron.left.circle.fill")
                                .font(.title2)
                                .foregroundColor(.red)
                        }
                        Spacer()
                    }
                    .padding()
                    
                    // 2. Galería de features
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 20), GridItem(.flexible())]) {
                            ForEach(features, id: \.1) { icon, title, subtitle, color, tab in
                                FeatureCard(
                                    icon: icon,
                                    title: title,
                                    subtitle: subtitle,
                                    color: color,
                                    action: { activeTab = tab }
                                )
                            }
                        }
                        .padding()
                    }
                    .navigationTitle("My Wellness")
                }
            }
            .navigationTitle(activeTab == nil ? "Mi Dashboard" : "")
            .toolbar {
                // Flecha para regresar al Dashboard desde TabViews
                if activeTab != nil {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button {
                            activeTab = nil // Vuelve al Dashboard
                        } label: {
                            Image(systemName: "chevron.left.circle.fill")
                                .foregroundColor(.pastelPink)
                        }
                    }
                }
            }
        }
    }
}
// 4. Tarjeta de característica reusable
struct FeatureCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .frame(width: 60, height: 60)
                    .background(color.gradient)
                    .clipShape(Circle())
                    .padding(.bottom, 5)
                
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(20)
            .background(Color(.systemBackground))
            .cornerRadius(15)
            .shadow(color: color.opacity(0.2), radius: 5, y: 3)
        }
    }
}
