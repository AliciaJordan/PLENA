import SwiftUI
struct SigninView: View {
    @State private var name = ""
    @State private var lastname = ""
    @State private var username = ""
    @State private var password = ""
    @State private var isSignedIn = false
    @State var backPressed = false
    var body: some View {
        NavigationStack {
            ZStack {
                Color.pastelGreen.ignoresSafeArea()
                VStack(spacing: 40) {
                    Text("Welcome to Plena")
                        .font(.title)
                        .foregroundColor(.white)
                        .brightness(/*@START_MENU_TOKEN@*/0.60/*@END_MENU_TOKEN@*/)
                    
                    
                    TextField("Name", text: $name)
                        .textFieldStyle(.roundedBorder)
                        .padding(.horizontal)
                    
                    TextField("Lastname", text: $lastname)
                        .textFieldStyle(.roundedBorder)
                        .padding(.horizontal)
                    
                    TextField("Username", text: $username)
                        .textFieldStyle(.roundedBorder)
                        .padding(.horizontal)
                    
                    SecureField("Password", text: $password)
                        .textFieldStyle(.roundedBorder)
                        .padding(.horizontal)
                    
                    Button("Sign in") {
                        isSignedIn = true
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.cyan)
                    
                    Button("I already have an account") {
                        backPressed = true
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.pastelPink)
                }
                .padding(.top, 50)
            }
            .fullScreenCover(isPresented: $isSignedIn) {
                MainDashboardView()
            }
            .fullScreenCover(isPresented: $backPressed) {
                LoginView()
            }
        }
    }
}
