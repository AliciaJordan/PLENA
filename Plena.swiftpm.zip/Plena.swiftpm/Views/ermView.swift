import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Header
                VStack(alignment: .leading, spacing: 8) {
                    Text("Your appointments")
                        .font(.headline)
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)
               
                // Appointments Section
                VStack(spacing: 16) {
                    // Last Appointment
                    appointmentCard(
                        title: "Last appointment",
                        subtitle: "Eating well",
                        status: "Finished",
                        time: "10:00-11:00",
                        isActive: false
                    )
                   
                    // Active Session
                    appointmentCard(
                        title: "Active session",
                        subtitle: "Home Name",
                        status: "Join",
                        time: nil,
                        isActive: true
                    )
                   
                    // Tuesday Contact
                    appointmentCard(
                        title: "Tuesday Contact",
                        subtitle: "Self-esteem",
                        status: "Unassigned",
                        time: nil,
                        isActive: false
                    )
                }
                .padding()
               
                Divider()
                    .padding(.vertical, 8)
               
                // Welcome Section
                VStack(spacing: 12) {
                    Text("Welcome to PLENA")
                        .font(.title2)
                        .fontWeight(.semibold)
                   
                    Text("Log how you're feeling today! ")
                        .font(.body .bold())
                        .foregroundColor(.purple)
                }
                .padding()
               
                Spacer()
                
                // Bottom Navigation
                HStack {
                    bottomNavItem(icon: "calendar", title: "Calendar", isSelected: false)
                    bottomNavItem(icon: "book", title: "Story for today!", isSelected: true)
                    bottomNavItem(icon: "person", title: "Profile", isSelected: false)
                }
                .padding()
                .background(Color(.systemGray6))
            }
            .navigationBarHidden(true)
        }
    }
   
    private func appointmentCard(title: String, subtitle: String, status: String, time: String?, isActive: Bool) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
           
            Spacer()
           
            VStack(alignment: .trailing, spacing: 4) {
                Text(status)
                    .font(.subheadline)
                    .foregroundColor(isActive ? .pink : .gray)
                if let time = time {
                    Text(time)
                        .font(.caption)
                        .foregroundColor(.red)
                }
            }
        }
        .padding()
        .background(isActive ? Color.purple.opacity(0.1) : Color(.systemGray6))
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(isActive ? Color.purple : Color.clear, lineWidth: 1)
        )
    }
   
    private func bottomNavItem(icon: String, title: String, isSelected: Bool) -> some View {
        VStack(spacing: 3) {
            Image(systemName: icon)
                .font(.system(size: 20))
            Text(title)
                .font(.caption)
        }
        .frame(maxWidth: .infinity)
        .foregroundColor(isSelected ? .purple : .gray)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
