import SwiftUI

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isLoggedIn = false
    @State private var toSignIn = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.pastelBlue.ignoresSafeArea()
                VStack(spacing: 40) {
                    Text("PLENA")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    TextField("User", text: $username)
                        .textFieldStyle(.roundedBorder)
                    
                    SecureField("Password", text: $password)
                        .textFieldStyle(.roundedBorder)
                    
                    Button("Log in", action: { isLoggedIn = true })
                        .buttonStyle(PlenaButtonStyle())
                    
                    Button("Sign in", action: { toSignIn = true })
                        .buttonStyle(PlenaButtonStyle(color: .cyan))
                }
                .padding(.horizontal, 30)
            }
            .fullScreenCover(isPresented: $isLoggedIn) {
                MainDashboardView() // Redirige aquí
                    .navigationBarBackButtonHidden(true)
            }
            .fullScreenCover(isPresented: $toSignIn) {
                SigninView() 
            }
        }
    }
}

