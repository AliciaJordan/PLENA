import SwiftUI

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isLoggedIn = false
    @State private var toSignIn = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.white.ignoresSafeArea()
                VStack(spacing: 40) {
                    
                    Image("Plena logo")
                        .resizable()
                        .frame(width: 300, height: 230)
                    
                    
                    TextField("User", text: $username)
                        .textFieldStyle(.roundedBorder)
                    
                    SecureField("Password", text: $password)
                        .textFieldStyle(.roundedBorder)
                    
                    Button("Log in", action: { isLoggedIn = true })
                        .buttonStyle(PlenaButtonStyle(color: .pastelPurple))
                    
                    Button("Sign in", action: { toSignIn = true })
                        .buttonStyle(PlenaButtonStyle(color: .cyan.opacity(0.9)))
                }
                .padding(.horizontal, 30)
            }
            .fullScreenCover(isPresented: $isLoggedIn) {
                ContentView() // Redirige aquí
                    .navigationBarBackButtonHidden(true)
            }
            .fullScreenCover(isPresented: $toSignIn) {
                SigninView() 
            }
        }
    }
}

