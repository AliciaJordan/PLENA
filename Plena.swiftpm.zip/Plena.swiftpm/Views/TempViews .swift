import SwiftUI

struct ExtrasView: View {
    var body: some View {
        VStack {
            Text("Opciones adicionales")
                .font(.title)
            // Añade aquí tus componentes extras
        }
    }
}

struct WeightTrackerView: View {
    @State private var weight: Double = 70
    
    var body: some View {
        VStack {
            Text("Registro de Peso")
                .font(.title.bold())
            
            Slider(value: $weight, in: 30...150, step: 0.5) {
                Text("Peso: \(weight, specifier: "%.1f") kg")
            }
            .padding()
            
            // Gráfica de progreso (ejemplo)
            Capsule()
                .frame(width: 200, height: 20)
                .foregroundColor(.pastelPink.opacity(0.3))
                .overlay(alignment: .leading) {
                    Capsule()
                        .frame(width: CGFloat(weight)/150 * 200)
                        .foregroundColor(.pastelPink)
                }
        }
    }
}
