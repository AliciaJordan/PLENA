import SwiftUI

enum HealthMetric: String, CaseIterable {
    case heartRate = "Heart Rate"
    case sleep = "Sleep"
    case steps = "Steps"
}

struct HealthDashboardView: View {
    @State private var weight: Double = 150 // lbs
    @State private var height: Double = 65 // inches
    @State private var age: Int = 30
    @State private var selectedMetric: HealthMetric = .heartRate
    
    // Sample health data
    private let healthData: [HealthMetric: [Double]] = [
        .heartRate: [72, 75, 80, 78, 76],
        .sleep: [6.5, 7, 6, 7.5, 8],
        .steps: [4500, 6000, 3000, 7000, 8000]
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    Text("Health Dashboard")
                        .font(.largeTitle.bold())
                        .foregroundColor(.pastelBlue)
                    
                    
                    // Metrics Sliders
                    VStack(spacing: 20) {
                        HealthSlider(value: $weight, 
                                     range: 80...300, 
                                     label: "Weight (lbs)", 
                                     icon: "scalemass")
                        
                        HealthSlider(value: $height, 
                                     range: 48...90, 
                                     label: "Height (in)", 
                                     icon: "ruler")
                        
                        HealthSlider(value: Binding(
                            get: { Double(age) },
                            set: { age = Int($0) }
                        ),
                                     range: 13...100,
                                     label: "Age",
                                     icon: "person")
                    }
                    .padding(.horizontal)
                    
                    // Metric Selector
                    Picker("Metric", selection: $selectedMetric) {
                        ForEach(HealthMetric.allCases, id: \.self) { metric in
                            Text(metric.rawValue).tag(metric)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal)
                    
                    // Health Data Visualization
                    VStack {
                        HStack {
                            Image(systemName: selectedMetric == .heartRate ? "heart.fill" : 
                                    selectedMetric == .sleep ? "bed.double" : "figure.walk")
                            .foregroundColor(.pastelPink)
                            Text("Last 5 Days")
                                .font(.headline)
                        }
                        
                        // Simple Bar Chart
                        HStack(alignment: .bottom, spacing: 10) {
                            ForEach(0..<5, id: \.self) { day in
                                VStack {
                                    Text(String(format: "%.1f", healthData[selectedMetric]![day]))
                                        .font(.caption)
                                    Rectangle()
                                        .fill(Color.pastelGreen)
                                        .frame(
                                            width: 30,
                                            height: CGFloat(healthData[selectedMetric]![day]) * 2
                                        )
                                    Text("Day \(day+1)")
                                        .font(.caption2)
                                }
                            }
                        }
                        .frame(height: 200)
                        .padding()
                    }
                    .background(Color.white.opacity(0.2))
                    .cornerRadius(15)
                    .padding(.horizontal)
                    
                    Spacer()
                }
                .padding(.top)
            }
            .background(Color.pastelGreen.opacity(0.1))
            .navigationBarTitleDisplayMode(.inline)
            
        }
    }
}

struct HealthSlider: View {
    @Binding var value: Double
    var range: ClosedRange<Double>
    var label: String
    var icon: String
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image(systemName: icon)
                Text(label)
                Spacer()
                Text("\(value, specifier: "%.0f")")
            }
            Slider(value: $value, in: range, step: 1)
                .tint(.pastelPink)
        }
    }
}
