import SwiftUI
struct HealthTabView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        TabView {
            NavigationStack {
                HealthDashboardView()
                    
            }
            .tabItem { Label("Metrics", systemImage: "heart.text.square") }
            
            NavigationStack {
                WeightTrackerView()
                    
            }
            .tabItem { Label("Weight", systemImage: "scalemass") }
        }
        .accentColor(.pastelPink)
    }
}

struct CheckInTabView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        TabView {
            NavigationStack {
                DailyCheckInView()
                   /* .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            BackButton(color: .pastelGreen)
                        }
                    }*/
            }
            .tabItem { Label("Check-In", systemImage: "calendar") }
            
            NavigationStack {
                ExtrasView()
            }
            .tabItem { Label("Extras", systemImage: "plus.circle") }
        }
        .accentColor(.pastelGreen)
    }
}
