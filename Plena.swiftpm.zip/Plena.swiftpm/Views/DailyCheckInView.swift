import SwiftUI
struct DailyCheckInView: View {
    @State private var selectedDate = Date()
    @State var backPressed = false
    @State var showHealthView = false
    var body: some View {
        NavigationStack {
            ZStack {
                Color.indigo.ignoresSafeArea()
                VStack {
                    DatePicker(
                        "Select Date",
                        selection: $selectedDate,
                        displayedComponents: [.date]
                    )
                    .datePickerStyle(.graphical)
                    .padding()
                    Spacer()
                    
                    }
                .padding(.bottom, 50)
            }
            .navigationDestination(isPresented: $showHealthView) {
                HealthDashboardView()  // ← Destination
            }
            
        }
    }
}
