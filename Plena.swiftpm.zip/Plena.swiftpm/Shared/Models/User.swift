import SwiftUI

struct User {
    var name: String
    var lastname: String
    var username: String
}
