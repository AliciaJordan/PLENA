import SwiftUI

// MARK: - Colors
extension Color {
    static let pastelBlue = Color(red: 0.68, green: 0.84, blue: 0.90)
    static let pastelPink = Color(red: 0.99, green: 0.79, blue: 0.82)
    static let pastelGreen = Color(red: 0.76, green: 0.89, blue: 0.78)
    static let pastelPurple = Color(red: 0.83, green: 0.69, blue: 0.85)
    static let pastelOrange = Color(red: 0.98, green: 0.80, blue: 0.64)
}

struct BackButton: View {
    let color: Color
    @Environment(\.dismiss) var dismiss // Mueve dismiss aquí
    
    var body: some View {
        Button(action: { dismiss() }) { // Ahora usa dismiss() directamente
            HStack(spacing: 4) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 18, weight: .semibold))
                Text("Back")
                    .font(.system(size: 16))
            }
            .foregroundColor(color)
        }
    }
}

// MARK: - Buttons
struct PlenaButtonStyle: ButtonStyle {
    var color: Color = .pastelPink
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .frame(maxWidth: .infinity)
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(10)
    }
}

